[![Build Status](https://github-drone.metrumrg.com/api/badges/metrumresearchgroup/PKPDmisc/status.svg)](https://github-drone.metrumrg.com/metrumresearchgroup/PKPDmisc)
[![CRAN_Status_Badge](https://www.r-pkg.org/badges/version-ago/PKPDmisc)](https://cran.r-project.org/package=PKPDmisc)
[![CRAN_Download_Badge](https://cranlogs.r-pkg.org/badges/PKPDmisc)](https://cran.r-project.org/package=PKPDmisc)


PKPDmisc
========

Check the [documentation](https://metrumresearchgroup.github.io/PKPDmisc).

## Installation information

PKPDmisc on CRAN:

```
install.packages("PKPDmisc")
```

or the development version:

```
devtools::install_github("metrumresearchgroup/PKPDmisc")
```
